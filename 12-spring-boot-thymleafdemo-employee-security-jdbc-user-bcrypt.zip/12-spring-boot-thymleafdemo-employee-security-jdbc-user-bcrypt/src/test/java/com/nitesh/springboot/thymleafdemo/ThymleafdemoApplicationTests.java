package com.nitesh.springboot.thymleafdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymleafdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
